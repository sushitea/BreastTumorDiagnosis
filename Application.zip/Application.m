function varargout = Application(varargin)
% APPLICATION MATLAB code for Application.fig
%      APPLICATION, by itself, creates a new APPLICATION or raises the existing
%      singleton*.
%
%      H = APPLICATION returns the handle to a new APPLICATION or the handle to
%      the existing singleton*.
%
%      APPLICATION('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in APPLICATION.M with the given input arguments.
%
%      APPLICATION('Property','Value',...) creates a new APPLICATION or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Application_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Application_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Application

% Last Modified by GUIDE v2.5 11-Apr-2019 12:24:44

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Application_OpeningFcn, ...
                   'gui_OutputFcn',  @Application_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

% --- Executes just before Application is made visible.
function Application_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Application (see VARARGIN)

% Choose default command line output for Application
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);
set(handles.axes1,'visible', 'off');
set(handles.axes2,'visible', 'off');
set(handles.axes3,'visible', 'off');
set(handles.axes4,'visible', 'off');
set(handles.axes5,'visible', 'off');
set(handles.axes6,'visible', 'off');
set(handles.axes7,'visible', 'off');
set(handles.axes8,'visible', 'off');

warning('off', 'Images:initSize:adjustingMag');
clc;
clear;

% UIWAIT makes Application wait for user response (see UIRESUME)
% uiwait(handles.figure1);

% --- Outputs from this function are returned to the command line.
function varargout = Application_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

% --- Executes on button press in open_mammogram.
function open_mammogram_Callback(hObject, eventdata, handles)
% hObject    handle to open_mammogram (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
cla(handles.axes1);
cla(handles.axes2);
cla(handles.axes3);
cla(handles.axes4);
cla(handles.axes5);
cla(handles.axes6);
cla(handles.axes7);
cla(handles.axes8);
set(handles.edit15,'String','-');
set(handles.edit16,'String','-');
set(handles.edit17,'String','-');
set(handles.edit18,'String','-');
set(handles.edit19,'String','-');
set(handles.edit20,'String','-');
set(handles.edit21,'String','-');
set(handles.edit22,'String','-');
set(handles.edit23,'String','-');
set(handles.edit24,'String','-');
set(handles.edit25,'String','-');

[file,path] = uigetfile('*.pgm','Select a mammogram');

if isequal(file,0)
   disp('User selected Cancel')
else
    a = strcat(path, file);
    axis image;
    Img = imread(a);
    
    axes(handles.axes1);
    
    % Show image
    imshow(Img);
    
end

% --- Executes on button press in pre_processing_method.
function pre_processing_method_Callback(hObject, eventdata, handles)
% hObject    handle to pre_processing_method (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
Mammogram_Image=getimage(handles.axes1);

Median_Filtering_Image = medfilt2(Mammogram_Image,[3,3]);
axes(handles.axes2);
imshow(Median_Filtering_Image);

Threshold_Image = imbinarize(Median_Filtering_Image,0.0706);
axes(handles.axes3);
imshow(Threshold_Image);

Label_Matrix_Image = bwlabel(Threshold_Image,8);
CC = bwconncomp(Threshold_Image, 8);
Temp_Largest_Area_Image = regionprops(CC, 'Area');
Small_Area_Label = labelmatrix(CC);
Largest_Area_Image = ismember(Small_Area_Label, find([Temp_Largest_Area_Image.Area] >= 50000));
axes(handles.axes4);
imshow(Largest_Area_Image);

Morphological_Image = bwmorph(Largest_Area_Image,'majority');
SE = strel('disk',5,4);
Erosion_Image = imerode(Morphological_Image,SE);
Dilation_Image = imdilate(Erosion_Image,SE);
Filled_Image = imfill(Dilation_Image,'holes');
mask = bwareafilt(Filled_Image, 1);
props = regionprops(mask, 'BoundingBox');
Temp_Final_Image = immultiply (Median_Filtering_Image,Filled_Image);
Cropped_Image = imcrop(Temp_Final_Image, props.BoundingBox);

Sum_Column = sum(Cropped_Image);
Sum_Column_First = Sum_Column(1)+Sum_Column(2)+Sum_Column(3)+Sum_Column(4)+Sum_Column(5)+Sum_Column(6)+Sum_Column(7)+Sum_Column(8)+Sum_Column(9)+Sum_Column(10);

Sum_Column_End = Sum_Column(end)+Sum_Column(end-1)+Sum_Column(end-2)+Sum_Column(end-3)+Sum_Column(end-4)+Sum_Column(end-5)+Sum_Column(end-6)+Sum_Column(end-7)+Sum_Column(end-8)+Sum_Column(end-9);

if (Sum_Column_First < Sum_Column_End)
    Correct_Orientation_Mammogram = fliplr(Cropped_Image);
else
    Correct_Orientation_Mammogram = Cropped_Image;
end
axes(handles.axes5);
imshow(Correct_Orientation_Mammogram);

% --- Executes on button press in segmentation_method.
function segmentation_method_Callback(hObject, eventdata, handles)
% hObject    handle to segmentation_method (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
Image_to_be_segmented=getimage(handles.axes5);
Image_Threshold = getimage(handles.axes6);
figure;
%imshow(Image_to_be_segmented);
subplot(1,2,1);
imshow(Image_Threshold);
subplot(1,2,2);
imshow(Image_to_be_segmented);
hold on;
[Final_x_coordinate,Final_y_coordinate] = ginput(1);
Final_x_coordinate = round(Final_x_coordinate);
Final_y_coordinate = round(Final_y_coordinate);
size_of_cropped_img = 256;
Final_Image = imcrop(Image_to_be_segmented,[Final_x_coordinate-128 Final_y_coordinate-128 size_of_cropped_img size_of_cropped_img]);
axes(handles.axes7);
imshow(Final_Image);
close figure 1;

% --- Executes on button press in histogram_equalisation.
function histogram_equalisation_Callback(hObject, eventdata, handles)
% hObject    handle to histogram_equalisation (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
Image_cropped=getimage(handles.axes7);
Final_Image = imadjust(Image_cropped,stretchlim(Image_cropped),[]);
axes(handles.axes8);
imshow(Final_Image);

% --- Executes on button press in classification_method.
function classification_method_Callback(hObject, eventdata, handles)
% hObject    handle to classification_method (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% saved_features = load ('features.mat');
set(handles.edit15,'String','-');
set(handles.edit16,'String','-');

global features;

load('First_Stage_Net.mat', 'net');

preliminary_result = net(features);
if preliminary_result <= 0.5
    set(handles.edit15, 'String', 1);
    set(handles.edit16, 'String', 'normal');
else
    load('Second_Stage_Net.mat', 'net1');
    secondary_result = net1(features);
    if secondary_result > 0.5
        set(handles.edit15, 'String', 2);
        set(handles.edit16, 'String', 'benign');
    else
        set(handles.edit15, 'String', 3);
        set(handles.edit16, 'String', 'malignant');
    end
end
    

% --- Executes during object creation, after setting all properties.
function axes2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to axes2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: place code in OpeningFcn to populate axes2

% --- Executes on button press in feature_extraction.
function feature_extraction_Callback(hObject, eventdata, handles)
% hObject    handle to feature_extraction (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
clear global features;
global features;

Image_to_be_feature_extraction = getimage(handles.axes8);
Image_to_be_feature_extraction_double = double(Image_to_be_feature_extraction);

m_mean=mean2(Image_to_be_feature_extraction(:));
m_variance=var(Image_to_be_feature_extraction_double(:));
m_skewness = skewness(Image_to_be_feature_extraction_double(:));
m_kurtosis=kurtosis(Image_to_be_feature_extraction_double(:));
m_entropy=entropy(Image_to_be_feature_extraction(:));

GLCM0 = graycomatrix(Image_to_be_feature_extraction,'offset',[2 0;0 2;0 2;2 0]);
stats = graycoprops(GLCM0,{'all'});
   
m_contrast = stats.Contrast;
m_correlation = stats.Correlation;
m_homogeneity = stats.Homogeneity;
m_energy = stats.Energy;

features = [m_mean m_variance m_skewness m_kurtosis m_entropy m_contrast m_correlation m_homogeneity m_energy];
features = transpose(features);
save('features.mat','features');

set(handles.edit17, 'String', num2str (m_mean));
set(handles.edit18, 'String', num2str (m_variance));
set(handles.edit19, 'String', num2str (m_skewness));
set(handles.edit20, 'String', num2str (m_kurtosis));
set(handles.edit21, 'String', num2str (m_entropy));
set(handles.edit22, 'String', num2str (m_contrast));
set(handles.edit23, 'String', num2str (m_correlation));
set(handles.edit24, 'String', num2str (m_homogeneity));
set(handles.edit25, 'String', num2str (m_energy));

% --- Executes on button press in thresholding.
function thresholding_Callback(hObject, eventdata, handles)
% hObject    handle to thresholding (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
Image_to_be_threshold=getimage(handles.axes5);
%str2num(char(get(handles.edit26,'String')));
value_of_threshold = str2double(char(get(handles.edit26,'String')));
Is_value_of_threshold = isnan(value_of_threshold);
if Is_value_of_threshold == 1
    output_value_of_threshold = 0.65;
else
    output_value_of_threshold = value_of_threshold;
end
Threshold_Image = imbinarize(Image_to_be_threshold,output_value_of_threshold);
axes(handles.axes6);
imshow(Threshold_Image);

function edit15_Callback(hObject, eventdata, handles)
% hObject    handle to edit15 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit15 as text
%        str2double(get(hObject,'String')) returns contents of edit15 as a double

% --- Executes during object creation, after setting all properties.
function edit15_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit15 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit16_Callback(hObject, eventdata, handles)
% hObject    handle to edit16 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit16 as text
%        str2double(get(hObject,'String')) returns contents of edit16 as a double

% --- Executes during object creation, after setting all properties.

function edit16_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit16 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit17_Callback(hObject, eventdata, handles)
% hObject    handle to edit17 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit17 as text
%        str2double(get(hObject,'String')) returns contents of edit17 as a double

% --- Executes during object creation, after setting all properties.
function edit17_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit17 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit18_Callback(hObject, eventdata, handles)
% hObject    handle to edit18 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit18 as text
%        str2double(get(hObject,'String')) returns contents of edit18 as a double

% --- Executes during object creation, after setting all properties.
function edit18_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit18 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit19_Callback(hObject, eventdata, handles)
% hObject    handle to edit19 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit19 as text
%        str2double(get(hObject,'String')) returns contents of edit19 as a double

% --- Executes during object creation, after setting all properties.
function edit19_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit19 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit20_Callback(hObject, eventdata, handles)
% hObject    handle to edit20 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit20 as text
%        str2double(get(hObject,'String')) returns contents of edit20 as a double

% --- Executes during object creation, after setting all properties.
function edit20_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit20 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit21_Callback(hObject, eventdata, handles)
% hObject    handle to edit21 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit21 as text
%        str2double(get(hObject,'String')) returns contents of edit21 as a double


% --- Executes during object creation, after setting all properties.
function edit21_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit21 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit22_Callback(hObject, eventdata, handles)
% hObject    handle to edit22 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit22 as text
%        str2double(get(hObject,'String')) returns contents of edit22 as a double


% --- Executes during object creation, after setting all properties.
function edit22_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit22 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit23_Callback(hObject, eventdata, handles)
% hObject    handle to edit23 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit23 as text
%        str2double(get(hObject,'String')) returns contents of edit23 as a double


% --- Executes during object creation, after setting all properties.
function edit23_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit23 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit24_Callback(hObject, eventdata, handles)
% hObject    handle to edit24 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit24 as text
%        str2double(get(hObject,'String')) returns contents of edit24 as a double


% --- Executes during object creation, after setting all properties.
function edit24_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit24 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit25_Callback(hObject, eventdata, handles)
% hObject    handle to edit25 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit25 as text
%        str2double(get(hObject,'String')) returns contents of edit25 as a double


% --- Executes during object creation, after setting all properties.
function edit25_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit25 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit26_Callback(hObject, eventdata, handles)
% hObject    handle to edit26 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit26 as text
%        str2double(get(hObject,'String')) returns contents of edit26 as a double


% --- Executes during object creation, after setting all properties.
function edit26_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit26 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
